# Conceitos de Design - Capital Bombas

## Abordagem 1: Industrial Minimalista com Tipografia Forte
**Design Movement:** Bauhaus Industrial + Swiss Style
**Probabilidade:** 0.08

### Core Principles
- Geometria limpa e funcional, sem ornamentação excessiva
- Tipografia hierárquica e assertiva como protagonista
- Paleta monocromática com destaques em cores técnicas (azul-aço, laranja industrial)
- Espaçamento generoso que comunica confiança e solidez

### Color Philosophy
- Fundo: Branco puro (#FFFFFF) ou cinza muito claro (#F8F9FA)
- Primária: Azul-aço profundo (#1E3A5F) - transmite confiabilidade técnica
- Destaque: Laranja industrial (#E67E22) - energia, ação, manutenção
- Neutros: Cinzas em escala (para hierarquia)
- Justificativa: Cores industriais inspiradas em equipamentos reais, evocam precisão e expertise

### Layout Paradigm
- Grid assimétrico 3-coluna com breakpoints responsivos
- Seções com alinhamento à esquerda (não centrado)
- Uso de linhas horizontais e verticais como divisores visuais
- Imagens de bombas em enquadramentos quadrados/retangulares rígidos

### Signature Elements
1. **Tipografia em Blocos:** Títulos em sans-serif bold (Poppins/Roboto Bold), corpo em regular
2. **Linhas Técnicas:** Linhas horizontais finas separando seções
3. **Ícones Geométricos:** Ícones simples, traçados finos, sem preenchimento

### Interaction Philosophy
- Transições suaves (200ms) em hover de botões
- Botões com borda, sem preenchimento (outline style)
- Hover: muda cor de fundo para laranja com texto branco
- Feedback visual claro e imediato

### Animation
- Fade-in suave (300ms) ao carregar seções
- Hover em cards: elevação sutil (shadow aumenta)
- Scroll reveal: elementos entram da esquerda com opacity fade

### Typography System
- **Display:** Poppins Bold 48-64px (títulos principais)
- **Heading:** Roboto Bold 32-40px (seções)
- **Body:** Roboto Regular 16px (texto corrido)
- **Caption:** Roboto Regular 12px (labels, pequenos textos)

---

## Abordagem 2: Corporativo Moderno com Gradientes Sutis
**Design Movement:** Contemporary Corporate + Glassmorphism
**Probabilidade:** 0.07

### Core Principles
- Design limpo e profissional com toques modernos
- Uso estratégico de gradientes e blur (glassmorphism)
- Componentes em cards com sombras suaves
- Paleta azul-verde (blue-green) que evoca tecnologia e confiança

### Color Philosophy
- Fundo: Gradiente sutil azul-escuro (#0F172A) a azul-médio (#1E3A5F)
- Primária: Cyan/Teal (#06B6D4) - modernidade, tech, confiança
- Secundária: Verde-água (#10B981) - crescimento, sustentabilidade
- Neutros: Brancos translúcidos para cards (glassmorphism)
- Justificativa: Gradientes suaves evocam movimento e progresso; cores frias transmitem profissionalismo

### Layout Paradigm
- Cards flutuantes com glassmorphism (backdrop-filter: blur)
- Layout em grid 2-3 colunas com espaçamento generoso
- Hero section com gradiente animado de fundo
- Seções alternadas (light/dark) para ritmo visual

### Signature Elements
1. **Cards com Glassmorphism:** Fundo semi-transparente com blur
2. **Gradientes Animados:** Gradientes suaves que mudam em scroll
3. **Ícones Coloridos:** Ícones com cores vibrantes (cyan, verde, roxo)

### Interaction Philosophy
- Hover em cards: elevação com sombra aumentada
- Botões com gradiente (cyan → verde)
- Transições suaves (250ms) em todas as interações
- Feedback visual com mudança de cor e escala

### Animation
- Entrada de cards com scale (0.95 → 1) + opacity fade
- Gradiente de fundo animado continuamente (subtle)
- Hover em botões: gradiente mais intenso
- Scroll reveal: elementos entram com parallax suave

### Typography System
- **Display:** Inter Bold 48-64px (títulos)
- **Heading:** Inter SemiBold 32-40px (seções)
- **Body:** Inter Regular 16px (corpo)
- **Caption:** Inter Regular 12px (labels)

---

## Abordagem 3: Técnico-Robusto com Textura e Profundidade
**Design Movement:** Industrial Tech + Brutalism Digital
**Probabilidade:** 0.06

### Core Principles
- Design robusto e "pesado" que transmite força e durabilidade
- Texturas sutis (grain, noise) para adicionar dimensão
- Cores quentes e terrosas com toques de neon
- Tipografia com peso e presença forte

### Color Philosophy
- Fundo: Cinza escuro com textura (#2A2A2A) ou preto com grain
- Primária: Vermelho industrial (#D32F2F) - energia, ação, urgência
- Secundária: Dourado/Cobre (#B8860B) - qualidade, expertise
- Destaque: Verde neon (#00FF41) - tecnologia, monitoramento
- Justificativa: Cores quentes evocam força; textura adiciona realismo; neon sugere tecnologia avançada

### Layout Paradigm
- Blocos grandes e pesados com bordas definidas
- Imagens com molduras espessas e sombras profundas
- Seções com fundo texturizado (grain/noise)
- Tipografia grande e assertiva

### Signature Elements
1. **Textura de Fundo:** Grain sutil em toda a página
2. **Bordas Espessas:** Linhas e molduras com 3-4px de espessura
3. **Sombras Profundas:** Sombras grandes que criam profundidade

### Interaction Philosophy
- Hover em botões: mudança de cor para neon com efeito glow
- Cliques com feedback tátil (scale 0.98)
- Transições rápidas (150ms) para sensação de responsividade
- Feedback visual agressivo e claro

### Animation
- Entrada de elementos com slide + fade (300ms)
- Hover em cards: sombra aumenta drasticamente
- Botões com efeito glow em hover
- Scroll reveal: elementos entram com bounce suave

### Typography System
- **Display:** Bebas Neue Bold 52-72px (títulos impactantes)
- **Heading:** Roboto Bold 36-44px (seções)
- **Body:** Roboto Regular 16px (corpo)
- **Caption:** Roboto Regular 12px (labels)

---

## Decisão Final

**Abordagem Selecionada: Industrial Minimalista com Tipografia Forte**

Esta abordagem foi escolhida porque:
1. **Credibilidade:** Transmite profissionalismo e confiança, essencial para B2B industrial
2. **Conversão:** Design limpo reduz distrações e direciona atenção para CTAs
3. **Responsividade:** Grid assimétrico é naturalmente responsivo
4. **Diferenciação:** Evita o clichê de "design corporativo genérico" mantendo funcionalidade
5. **SEO/Google Ads:** Carregamento rápido, estrutura clara, fácil de rastrear

### Aplicação Prática
- Paleta: Azul-aço (#1E3A5F) + Laranja (#E67E22) + Brancos/Cinzas
- Tipografia: Poppins Bold para títulos, Roboto Regular para corpo
- Componentes: Cards simples, botões outline, linhas divisórias
- Animações: Suaves (200-300ms), fade-in e hover effects
- Imagens: Enquadramentos rígidos, sem efeitos excessivos
